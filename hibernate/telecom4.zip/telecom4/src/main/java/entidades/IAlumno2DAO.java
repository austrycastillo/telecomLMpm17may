package entidades;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.*;
@Repository
@Service
public interface IAlumno2DAO extends CrudRepository<Alumno2,Integer> {

}
