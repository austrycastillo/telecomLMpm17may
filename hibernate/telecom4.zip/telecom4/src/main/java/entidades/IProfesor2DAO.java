package entidades;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface IProfesor2DAO extends CrudRepository<Profesor2,Integer>{

}
