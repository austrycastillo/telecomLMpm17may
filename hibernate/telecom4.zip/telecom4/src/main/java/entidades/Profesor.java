package entidades;

import javax.persistence.*;

@Entity
@Table
public class Profesor extends Persona {
	@Column
	private String codigo;

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	
}
