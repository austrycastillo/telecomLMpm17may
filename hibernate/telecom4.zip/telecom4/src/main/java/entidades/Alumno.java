package entidades;

import javax.persistence.*;

@Entity
@Table
public class Alumno extends Persona {
	@Column
	private Double nota;

	public Double getNota() {
		return nota;
	}

	public void setNota(Double nota) {
		this.nota = nota;
	}
	
}
