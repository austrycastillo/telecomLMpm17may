package entidades;

import javax.persistence.*;
@Entity
@Table
public class Alumno2 extends Persona2{
	@Column
	private Double nota;

	public Double getNota() {
		return nota;
	}

	public void setNota(Double nota) {
		this.nota = nota;
	}
}
