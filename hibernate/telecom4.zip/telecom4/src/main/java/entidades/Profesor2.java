package entidades;

import javax.persistence.*;
@Entity
@Table
public class Profesor2 extends Persona2{
	@Column
	private String codigo;

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
}
