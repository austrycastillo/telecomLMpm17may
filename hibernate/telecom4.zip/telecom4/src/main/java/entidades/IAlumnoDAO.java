package entidades;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.*;
@Repository
@Service
public interface IAlumnoDAO extends CrudRepository<Alumno,Integer> {

}
