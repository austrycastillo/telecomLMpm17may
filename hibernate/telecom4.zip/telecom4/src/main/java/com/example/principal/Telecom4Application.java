package com.example.principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import entidades.Alumno;
import entidades.Alumno2;
import entidades.IAlumno2DAO;
import entidades.IAlumnoDAO;
import entidades.IProfesor2DAO;
import entidades.IProfesorDAO;
import entidades.Profesor;
import entidades.Profesor2;

@SpringBootApplication
@ComponentScan({"entidades"})
@EntityScan("entidades")
@EnableJpaRepositories("entidades")
public class Telecom4Application implements CommandLineRunner {
	@Autowired
	IAlumnoDAO ad;
	@Autowired
	IProfesorDAO pd;
	@Autowired
	IAlumno2DAO ad2;
	@Autowired
	IProfesor2DAO pd2;
	public static void main(String[] args) {
		SpringApplication.run(Telecom4Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		/*Alumno a1 = new Alumno();
		a1.setNombre("Yanina");
		a1.setApellido("Prudencio");
		a1.setNota(10.0);
				
		Alumno a2 = new Alumno();
		a2.setNombre("Lourdes");
		a2.setApellido("Lizondo");
		a2.setNota(8.5);
		
		Profesor p1 = new Profesor();
		p1.setNombre("Austry");
		p1.setApellido("Castillo");
		p1.setCodigo("abc123");
		
		
		Profesor p2 = new Profesor();
		p2.setNombre("Martin");
		p2.setApellido("Torres");
		p2.setCodigo("egd853");
		
		ad.save(a1);
		ad.save(a2);
		pd.save(p1);
		pd.save(p2);*/
		Alumno2 a1 = new Alumno2();
		a1.setNombre("Yanina");
		a1.setApellido("Prudencio");
		a1.setNota(10.0);
		
		Alumno2 a2 = new Alumno2();
		a2.setNombre("Lourdes");
		a2.setApellido("Lizondo");
		a2.setNota(8.5);
		
		Profesor2 p1 = new Profesor2();
		p1.setNombre("Austry");
		p1.setApellido("Castillo");
		p1.setCodigo("abc123");
		
		
		Profesor2 p2 = new Profesor2();
		p2.setNombre("Martin");
		p2.setApellido("Torres");
		p2.setCodigo("egd853");
		
		ad2.save(a1);
		ad2.save(a2);
		pd2.save(p1);
		pd2.save(p2);
		
	}

}
