package com.trabajo1.principal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Trabajo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
