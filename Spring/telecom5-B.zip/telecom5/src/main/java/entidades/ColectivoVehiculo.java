package entidades;

import interfaces.Vehiculos;

public class ColectivoVehiculo implements Vehiculos {
	private Informar informe;

	public ColectivoVehiculo(Informar informe) {
		this.informe = informe;
	}

	@Override
	public String getCapacidad() {
		return "capacidad para 40 personas";
	}

	@Override
	public String getInformar() {
		return " El colectivo tiene blabla " 
				+ informe.getInformar();
	}

}
