package entidades;

import interfaces.Vehiculos;

public class MotoVehiculo implements Vehiculos {
	private Informar informe;
	
	public MotoVehiculo(Informar informe) {
		this.informe = informe;
	}

	@Override
	public String getCapacidad() {
		return "Capacidad para 2 personas";
	}

	@Override
	public String getInformar() {
		return " La moto tiene permisos según el reglamento dispuesto blabla " 
	+ informe.getInformar();
	}

}
