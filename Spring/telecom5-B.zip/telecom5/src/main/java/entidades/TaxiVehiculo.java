package entidades;

import interfaces.Vehiculos;

public class TaxiVehiculo implements Vehiculos {
	private Informar informe;
	public TaxiVehiculo(Informar informe) {
		this.informe = informe;
	}
	public String getCapacidad() {
		return "capacidad para 3 personas";
	}

	@Override
	public String getInformar() {
		
		return " El taxi tiene permisos requeridos blabla " + informe.getInformar();
	}
}
