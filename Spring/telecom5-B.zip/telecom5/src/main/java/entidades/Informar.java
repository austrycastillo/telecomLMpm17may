package entidades;

public class Informar implements interfaces.Informar {

	@Override
	public String getInformar() {
		
		return "Esto es una presentación blabla del vehículo";
	}

}
