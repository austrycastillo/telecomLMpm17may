package anotaciones;

import org.springframework.stereotype.Component;

@Component("MotoChofer") //anotación para registrar el bean
public class MotoChofer implements Chofer {

	@Override
	public String getTareas() {
		return "manejar y manejar moto";
	}

}
