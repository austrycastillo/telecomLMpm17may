package anotaciones;

public interface Chofer {
	public String getTareas();
}
