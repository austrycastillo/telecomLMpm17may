package interfaces;

public interface Informar {
		public String getInformar();
}
