package com.example.principal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import anotaciones.Chofer;
import entidades.ColectivoVehiculo;
import entidades.MotoVehiculo;
import entidades.TaxiVehiculo;
import interfaces.Vehiculos;

@SpringBootApplication
public class Telecom5Application {

	public static void main(String[] args) {
		//SpringApplication.run(Telecom5Application.class, args);
		/*TaxiVehiculo taxi1 = new TaxiVehiculo();
		System.out.println(taxi1.getCapacidad());
		ColectivoVehiculo cole1 = new ColectivoVehiculo();
		System.out.println(cole1.getCapacidad());
		MotoVehiculo moto1 = new MotoVehiculo();
		System.out.println(moto1.getCapacidad());*/
		//crear un contexto para que cargue el xml
		ClassPathXmlApplicationContext contexto = new ClassPathXmlApplicationContext("ApplicationContext.xml");
		/* Probando IoC
		 * Vehiculos v1 = contexto.getBean("miTaxi",Vehiculos.class);
		System.out.println(v1.getCapacidad());
		Vehiculos v2 = contexto.getBean("miMoto",Vehiculos.class);
		System.out.println(v2.getCapacidad());
		Vehiculos v3 = contexto.getBean("miColectivo",Vehiculos.class);
		System.out.println(v3.getCapacidad());
		contexto.close();*/
		//Probando DI
		/*Vehiculos v1 = contexto.getBean("miTaxi",Vehiculos.class);
		System.out.println(v1.getCapacidad());
		System.out.println(v1.getInformar());
		Vehiculos m1 = contexto.getBean("miMoto",Vehiculos.class);
		System.out.println(m1.getCapacidad());
		System.out.println(m1.getInformar());
		Vehiculos c1 = contexto.getBean("miColectivo",Vehiculos.class);
		System.out.println(c1.getCapacidad());
		System.out.println(c1.getInformar());
		contexto.close();*/
		//Probando con anotaciones
		Chofer ch1 = contexto.getBean("MotoChofer",Chofer.class);
		System.out.println(ch1.getTareas());
		contexto.close();
	}

}
