package entidades;

import interfaces.Vehiculos;

public class TaxiVehiculo implements Vehiculos {
	public String getCapacidad() {
		return "capacidad para 3 personas";
	}
}
