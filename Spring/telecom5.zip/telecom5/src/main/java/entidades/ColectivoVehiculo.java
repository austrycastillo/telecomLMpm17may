package entidades;

import interfaces.Vehiculos;

public class ColectivoVehiculo implements Vehiculos {

	@Override
	public String getCapacidad() {
		// TODO Auto-generated method stub
		return "capacidad para 40 personas";
	}

}
