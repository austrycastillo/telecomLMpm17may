package entidades;

import interfaces.Vehiculos;

public class MotoVehiculo implements Vehiculos {

	@Override
	public String getCapacidad() {
		// TODO Auto-generated method stub
		return "Capacidad para 2 personas";
	}

}
