package interfaces;

public interface Vehiculos {
	public String getCapacidad();
}
