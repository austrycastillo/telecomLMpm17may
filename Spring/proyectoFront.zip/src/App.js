import React from "react";
import UsuarioComponente from "./componentes/UsuarioComponente";
class App extends React.Component {
 

  render() {
    
    return (
      <>
       <UsuarioComponente/>
      </>
    );
  }
}
export default App;
